package ch06.sec07.exam01;

public class Car {
    String model;
    String color;
    int speed;

    // 생성자
    public Car(String model, String color, int speed) {
        this.model = model;
        this.color = color;
        this.speed = speed;
    }
}

package ch06.sec07.exam01;

public class CarExample {
    public static void main(String[] args) {
        Car myCar = new Car("그랜저", "검정", 250);
        // Car myCar = new Car();  // 기본 생성자 호출 못함
    }
}