package ch06.sec06.exam01;

public class Car {
    // 필드 선언
    String model;
    boolean start;
    int speed;
}
// String model의 기본값: null
// boolean start의 기본값: false
// int speed의 기본값: 0
